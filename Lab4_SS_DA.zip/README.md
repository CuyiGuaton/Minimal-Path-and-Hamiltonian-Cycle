# Ciclo minimo y Ciclo hamiltoniano

Para compilar se debe ingresar el comando

```
gcc hamiltoncycle.c && ./a.out n p

```

Donde n es la cantidad de vértices que se desea que tenga el grafo y p es la probabilidad de que hayan más aristas entre los vértices.

Si el ciclo hamiltoniano termina con un X significa que no hay un ciclo hamiltoniano, por el contrario, si termina con el mismo vértice que empezo entonces si existe.
